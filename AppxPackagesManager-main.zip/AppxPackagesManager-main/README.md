# AppxPackagesManager

[![Downloads](https://img.shields.io/github/downloads/valleyofdoom/AppxPackagesManager/total.svg)](https://github.com/valleyofdoom/AppxPackagesManager/releases)

![program-screenshot.png](/assets/img/program-screenshot.png)
